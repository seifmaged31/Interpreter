package Main;

public class Variable {
    String name;
    String value;
    public Variable(String name,String value){
        this.name = name;
        this.value = value;
    }
}
