package Main;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.util.Scanner;

public class Interpreter {

String programName ;
ArrayList<Variable> variables;
public Interpreter(String filepath) throws Exception {
    File file = new File(filepath);
    BufferedReader br = new BufferedReader(new FileReader(file));
    variables = new ArrayList<>();
    readProgram(br);
}


    public void readProgram(BufferedReader br) throws Exception {
        String st;
        while ((st = br.readLine()) != null) {
            String[] arrOfStr = st.split(" ");
            int index = arrOfStr.length - 1 ;
            while (index >= 0){
                check(arrOfStr,index);
                index--;
            }
        }
    }
    public String readFile(String fileName)throws Exception
    {
        fileName = getvalue(fileName);
        String data = "";
        fileName = "src/Resources/" + fileName + ".txt" ;
        File file = new File(fileName);
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        while ((st = br.readLine()) != null) {
            data = data + st;
        }
        return data;
    }
    public void print (String x){
    x = getvalue(x) ;
    System.out.println(x);
    }
    public void writeFile(String fileName, String data) throws IOException {
        fileName = getvalue(fileName);
        fileName = "src/Resources/" + fileName + ".txt" ;
        data = getvalue(data);
    try {
            FileWriter out = new FileWriter(fileName);
            out.write(data);
            out.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        System.out.println("Success...");
    }
    public void assign (String variable, Object value){
        Variable variable1 = new Variable(variable,value.toString());
        variables.add(variable1);

    }
    public String add (String variable,String value){
        for(Variable var:variables){
            if(var.name.equals(value)){
                value =  var.value ;
                break;
            }
        }
        for(Variable var:variables){
            if(var.name.equals(variable)){
              var.value = ((Integer.parseInt(value)+Integer.parseInt(var.value)))+"";
                return var.value;
            }
        }
        return null;
    }
    public void check (String[] line,int i) throws Exception {
        if(line[i].equals("add")){
            line[i] = add(line[i+1],line[i+2]);
            return;
        }
        if(line[i].equals("readFile")){
           line[i]=readFile(line[i+1]); return;
        }
        if(line[i].equals("assign")){
            assign(line[i+1],line[i+2]);
            line[i]=line[i+1];
            return;
        }
        if(line[i].equals("writeFile")){
            writeFile(line[i+1],line[i+2]); return;
        }
        if(line[i].equals("print")){
            print(line[i+1]); return;
        }
        if(line[i].equals("input")){
            Scanner sc = new Scanner(System.in);
            line[i]=sc.nextLine();
        }
    }
    public String getvalue (String input){
        for(Variable variable:variables){
            if (variable.name.equals(input)){
                return variable.value;
            }
        }
        return input;
    }

    public static void main(String[] args) throws Exception {
        Interpreter test = new Interpreter("src/Resources/Program 2.txt");
        //writeFile("/Users/youssefsameh/Desktop/OS/src/Resources/YSR.txt","SEEIIFFF");
        //readFile("/Users/youssefsameh/Desktop/OS/src/Resources/YSR.txt");
    }
}
